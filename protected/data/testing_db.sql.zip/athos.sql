-- phpMyAdmin SQL Dump
-- version 3.3.7deb5build0.10.10.1
-- http://www.phpmyadmin.net
--
-- Servidor: localhost
-- Tiempo de generación: 22-04-2012 a las 22:04:26
-- Versión del servidor: 5.1.61
-- Versión de PHP: 5.3.3-1ubuntu9.10

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de datos: `athos`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `continent`
--

CREATE TABLE IF NOT EXISTS `continent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `country`
--

CREATE TABLE IF NOT EXISTS `country` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=69 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `employees`
--

CREATE TABLE IF NOT EXISTS `employees` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `first_name` varchar(50) NOT NULL,
  `last_name` varchar(50) NOT NULL,
  `email` varchar(100) NOT NULL,
  `phone_office` varchar(50) DEFAULT NULL,
  `phone_office_ext` varchar(20) DEFAULT NULL,
  `phone_home` varchar(50) DEFAULT NULL,
  `phone_mobile` varchar(50) DEFAULT NULL,
  `fax` varchar(50) DEFAULT NULL,
  `position` varchar(100) DEFAULT NULL,
  `current_position` tinyint(1) NOT NULL,
  `archived_position` tinyint(1) NOT NULL,
  `skype` varchar(50) DEFAULT NULL,
  `personal_note` text,
  `office_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `office_fk_1` (`office_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=9145 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `employeescontinent`
--

CREATE TABLE IF NOT EXISTS `employeescontinent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employees_id` int(10) unsigned NOT NULL,
  `continent_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_employeescontinent_fk_1` (`employees_id`,`continent_id`),
  KEY `region_employeescontinent_fk_1` (`continent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `employeesregion`
--

CREATE TABLE IF NOT EXISTS `employeesregion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employees_id` int(10) unsigned NOT NULL,
  `region_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_employeesregion_fk_1` (`employees_id`,`region_id`),
  KEY `region_employeesregion_fk_1` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `employeessector`
--

CREATE TABLE IF NOT EXISTS `employeessector` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `employees_id` int(10) unsigned NOT NULL,
  `sector_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `employees_employeessector_fk_1` (`employees_id`,`sector_id`),
  KEY `region_employeessector_fk_1` (`sector_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `firm`
--

CREATE TABLE IF NOT EXISTS `firm` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(70) NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `firmtype_id` int(10) unsigned NOT NULL,
  `description` text,
  `website` varchar(100) NOT NULL,
  `rank` varchar(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `firm_firmtype_fk_1` (`firmtype_id`),
  KEY `firm_user_fk_1` (`user_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3263 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `firmcontinent`
--

CREATE TABLE IF NOT EXISTS `firmcontinent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firm_id` int(10) unsigned NOT NULL,
  `continent_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `firm_firmcontinent_fk_1` (`firm_id`,`continent_id`),
  KEY `region_firmcontinent_fk_1` (`continent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `firmdocument`
--

CREATE TABLE IF NOT EXISTS `firmdocument` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firm_id` int(10) unsigned NOT NULL,
  `file` varchar(30) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `firm_firmdocument_fk_1` (`firm_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `firmregion`
--

CREATE TABLE IF NOT EXISTS `firmregion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `firm_id` int(10) unsigned NOT NULL,
  `region_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `firm_firmregion_fk_1` (`firm_id`,`region_id`),
  KEY `region_firmregion_fk_1` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `firmtype`
--

CREATE TABLE IF NOT EXISTS `firmtype` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gp`
--

CREATE TABLE IF NOT EXISTS `gp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firm_id` int(11) NOT NULL,
  `rank` varchar(1) NOT NULL,
  `name` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  `website` int(11) NOT NULL,
  `top_interests` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `firm_id` (`firm_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=6 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gpcontinent`
--

CREATE TABLE IF NOT EXISTS `gpcontinent` (
  `gp_id` int(11) NOT NULL,
  `continent_id` int(11) NOT NULL,
  KEY `gp_id` (`gp_id`,`continent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gpdocument`
--

CREATE TABLE IF NOT EXISTS `gpdocument` (
  `id` int(11) NOT NULL,
  `gp_id` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gp_id` (`gp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gpregion`
--

CREATE TABLE IF NOT EXISTS `gpregion` (
  `gp_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  PRIMARY KEY (`region_id`,`gp_id`),
  UNIQUE KEY `gp_id_2` (`gp_id`,`region_id`),
  KEY `gp_id` (`gp_id`,`region_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `gpsector`
--

CREATE TABLE IF NOT EXISTS `gpsector` (
  `gp_id` int(11) NOT NULL,
  `sector_id` int(11) NOT NULL,
  PRIMARY KEY (`gp_id`,`sector_id`),
  KEY `gp_id` (`gp_id`,`sector_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lp`
--

CREATE TABLE IF NOT EXISTS `lp` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firm_id` int(11) NOT NULL,
  `rank` text NOT NULL,
  `assets_in_euro` bigint(20) NOT NULL,
  `assets_original` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `assets_umgmt_ori` bigint(20) NOT NULL,
  `top_interests` varchar(50) NOT NULL,
  `assets_umgmt` bigint(20) NOT NULL,
  `website` varchar(50) NOT NULL,
  `description` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `firm_id` (`firm_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=4 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lpcontinent`
--

CREATE TABLE IF NOT EXISTS `lpcontinent` (
  `lp_id` int(11) NOT NULL,
  `continent_id` int(11) NOT NULL,
  KEY `lp_id` (`lp_id`,`continent_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lpdocument`
--

CREATE TABLE IF NOT EXISTS `lpdocument` (
  `id` int(11) NOT NULL,
  `lp_id` int(11) NOT NULL,
  `file` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `gp_id` (`lp_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lpregion`
--

CREATE TABLE IF NOT EXISTS `lpregion` (
  `lp_id` int(11) NOT NULL,
  `region_id` int(11) NOT NULL,
  PRIMARY KEY (`lp_id`,`region_id`),
  KEY `lp_id` (`lp_id`,`region_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lpsector`
--

CREATE TABLE IF NOT EXISTS `lpsector` (
  `lp_id` int(11) NOT NULL,
  `sector_id` int(11) NOT NULL,
  PRIMARY KEY (`lp_id`,`sector_id`),
  KEY `lp_id` (`lp_id`,`sector_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `lptarget`
--

CREATE TABLE IF NOT EXISTS `lptarget` (
  `lp_id` int(11) NOT NULL,
  `target_id` int(11) NOT NULL,
  PRIMARY KEY (`lp_id`,`target_id`),
  KEY `lp_id` (`lp_id`,`target_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `office`
--

CREATE TABLE IF NOT EXISTS `office` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `country_id` int(10) unsigned NOT NULL,
  `main_office` tinyint(1) NOT NULL,
  `phone` varchar(50) NOT NULL,
  `address` varchar(100) NOT NULL,
  `city` varchar(100) NOT NULL,
  `state` varchar(100) NOT NULL,
  `description` text,
  `sync_gmaps` tinyint(1) NOT NULL,
  `firm_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `office_country_fk_1` (`country_id`),
  KEY `office_firm_fk_1` (`firm_id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3387 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `officecontinent`
--

CREATE TABLE IF NOT EXISTS `officecontinent` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `office_id` int(10) unsigned NOT NULL,
  `continent_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `office_officecontinent_fk_1` (`office_id`,`continent_id`),
  KEY `region_officecontinent_fk_1` (`continent_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `officeregion`
--

CREATE TABLE IF NOT EXISTS `officeregion` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `office_id` int(10) unsigned NOT NULL,
  `region_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `office_officeregion_fk_1` (`office_id`,`region_id`),
  KEY `region_officeregion_fk_1` (`region_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `region`
--

CREATE TABLE IF NOT EXISTS `region` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=23 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sector`
--

CREATE TABLE IF NOT EXISTS `sector` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `target`
--

CREATE TABLE IF NOT EXISTS `target` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tbl_migration`
--

CREATE TABLE IF NOT EXISTS `tbl_migration` (
  `version` varchar(255) NOT NULL,
  `apply_time` int(11) DEFAULT NULL,
  PRIMARY KEY (`version`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `user`
--

CREATE TABLE IF NOT EXISTS `user` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `password` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=8 ;
